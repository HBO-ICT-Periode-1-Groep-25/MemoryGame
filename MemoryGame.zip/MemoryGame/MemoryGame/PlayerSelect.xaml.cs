﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MemoryGame
{
    /// <summary>
    /// Interaction logic for PlayerSelect.xaml
    /// </summary>
    public partial class PlayerSelect : Page
    {
        public PlayerSelect()
        {
            InitializeComponent();
        }

        private void SpeelButton_Click(object sender, RoutedEventArgs e)
        {
            FrozenGameWindow objMainwindow = new FrozenGameWindow();
            objMainwindow.Show();
        }
    }
}
